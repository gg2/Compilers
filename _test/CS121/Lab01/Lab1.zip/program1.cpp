/* 
 * Gabe Gibler
 * CS121 Sec 03
 * Lab #1 
 * 2015/01/22
 *
 * 1) Modified output from that given.
 */

#include <iostream> // include the library with I/O commands

using namespace std;

int main() // beginning of the program
{
	cout << "Hello, CS 121 Lab #1!" << endl; // print some output
	return 0;
}