#include"node.h"

node::node() {
	next = NULL;	
	data = 0.0;
}