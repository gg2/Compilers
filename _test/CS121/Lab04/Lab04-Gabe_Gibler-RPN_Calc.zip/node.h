/*
 * Node for storing data for a Linked List
 */
#include<cstdlib>

class node {
	private:
		
	public:
		node();

		node *next;
		double data;
};
