/* 
 * stack_test.cpp
 *
 * CS 121 Sec 03 - Bolden
 * Gabe Gibler
 * 2015 Apr 2
 * gibl3465@vandals.uidaho.edu
 *
 * Program to test interface for stack
 *------------------------------------
 */

#include<iostream>
#include<cstdlib>

#include"stack.cpp"

int main()
{
	std::cout << "Stack Test\n" << std::endl;
	
	Stack S;
	int m = 0;
	int n = 0;
	
	std::cout << "Stack created ... \n";
	TestStack(S,m,n);
	m = 1;
	n = 1;
	TestStack(S,m,n);
	m = 0;
	n = 1;
	TestStack(S,m,n);
	m = -1;
	n = 0;
	TestStack(S,m,n);
	m = -50;
	n = 50;
	TestStack(S,m,n);

	std::cout << "List Zipping\n" << std::endl;
	
		
	// Exit program
	return 0;
}

void TestStack(Stack S, int m, int n) {
	std::cout << "Stack.size(): " << S.size() << "\n";
	std::cout << "Stack.top(): " << S.top() << "\n";
	std::cout << "Stack contents: ";
	S.print();
	std::cout << "Pushing value to stack ... \n";
	std::cout << "Pushing " << n << " elements onto stack ... \n";
	for (int i=m; i<n; i++) {
		S.push(i);
	}
	std::cout << "Stack.size(): " << S.size() << "\n";
	std::cout << "Stack.top(): " << S.top() << "\n";
	std::cout << "Stack contents: ";
	S.print();
	std::cout << "Popping values from stack ... \n";
	for (int i=m; i<n; i++) {
		std::cout << S.pop() << " ";
	}
	std::cout << "Stack.size(): " << S.size() << "\n";
	std::cout << "Stack contents: ";
	S.print();
	std::cout << "- - - - - - - - - - - - -\n" << endl;
}
